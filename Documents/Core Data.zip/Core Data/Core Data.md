
# CRUD Operation Cordata 



## Create Database

core data create with your project and database name is same to your project name.

Once the project is created, you will see a file like CoreDataTest.xcdatamodeld already created, you can also add the file to an existing project.

now create entity(table) in your project.
then add attributes(fields) in entity.

This steps define in screenshoot also check.
## Appdelegate.swift
```bash
   let appDelegate = UIApplication.shared.delegate as! AppDelegate
   let context = appDelegate.persistentContainer.viewContext
   
```
## Database.swift
```bash
// Data Added
  func interData(){
    let entity = NSEntityDescription.entity(forEntityName: "Users", in: context)
    let newUser = NSManagedObject(entity: entity!, insertInto: context)
    newUser.setValue("Abhishek", forKey: "username")
    newUser.setValue("2311", forKey: "password")
    newUser.setValue("21", forKey: "age")

    do { 
        try context.save()      
    } catch {      
        print("Error saving")
    }
  }

//Data Get
func fetchData(){
let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        //request.predicate = NSPredicate(format: "age = %@", "21")
request.returnsObjectsAsFaults = false        
    do {
            let result = try context.fetch(request)
            for data in result as! [NSManagedObject] 
        {       
             print(data.value(forKey: "username") as! String)
        }
       } catch {
           print("Failed")
        }
}

//Data Delete
func deleteData(){
let appDel:AppDelegate = (UIApplication.sharedApplication().delegate as AppDelegate)
let context = self.appDel.managedObjectContext!
    context.del(data)
    do {
        try context.save()
    }catch {
    // Handle Error
    }
}

// Data update
func updateData(){
//here only query for update data
//here person is entity name
let query = "Suraj"

let request: NSFetchRequest&lt;Person&gt; = Person.fetchRequest()request.predicate = NSPredicate(format: "name LIKE %@", query)request.predicate = NSPredicate(format: "name == %@", query)
}
```