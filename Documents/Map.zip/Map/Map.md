
# Map





## Info.plist
Add following key to info.plist

    <key>NSLocationAlwaysAndWhenInUseUsageDescription</key>
    <string>location</string>
    <key>NSLocationAlwaysUsageDescription</key>
    <string>location</string>
    <key>NSLocationUsageDescription</key>
    <string>location</string>
    <key>NSLocationWhenInUseUsageDescription</key>
    <string>location</string>




## mapVC.swift
```bash
import UIKit
import MapKit

class mapVC: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    let locationManager = CLLocationManager()
    
    struct Stadium {
         var name: String
         var lattitude: CLLocationDegrees
         var longtitude: CLLocationDegrees
       }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if CLLocationManager.locationServicesEnabled() {
          checkLocationAuthorization()
        }
                locationManager.delegate = self
               locationManager.requestAlwaysAuthorization()
               locationManager.startUpdatingLocation()
               locationManager.desiredAccuracy = kCLLocationAccuracyBest
        mapView.showsUserLocation = true
        
        let stadiums = [Stadium(name: "Amreli", lattitude: 21.6015, longtitude: 71.2204),
               Stadium(name: "Ahemdabad", lattitude: 23.0225, longtitude: 72.5714),
               Stadium(name: "Rajkot", lattitude: 22.3039, longtitude: 70.8022),
               Stadium(name: "Veraval", lattitude: 20.9159, longtitude: 70.3629),
               Stadium(name: "Jamanagar", lattitude: 22.4707, longtitude: 70.0577),
               Stadium(name: "Mumbai", lattitude: 19.0760, longtitude: 72.8777)]
               fetchStadiumsOnMap(stadiums)


        let sourceLocation = CLLocationCoordinate2D(latitude: 21.6015, longitude: 71.2204)
        let destinationLocation = CLLocationCoordinate2D(latitude: 23.0225, longitude: 72.5714)
        
        createPath(sourceLocation: sourceLocation, destinationLocation: destinationLocation)
        
        self.mapView.delegate = self
    }

    func createPath(sourceLocation : CLLocationCoordinate2D, destinationLocation : CLLocationCoordinate2D) {
        let sourcePlaceMark = MKPlacemark(coordinate: sourceLocation, addressDictionary: nil)
        let destinationPlaceMark = MKPlacemark(coordinate: destinationLocation, addressDictionary: nil)
        
        
        let sourceMapItem = MKMapItem(placemark: sourcePlaceMark)
        let destinationItem = MKMapItem(placemark: destinationPlaceMark)
        
        
        let sourceAnotation = MKPointAnnotation()
        sourceAnotation.title = "Amreli"
        sourceAnotation.subtitle = "Amreli is a city and a municipality in Amreli district in Indian state of Gujarat"
        if let location = sourcePlaceMark.location {
            sourceAnotation.coordinate = location.coordinate
        }
        
        let destinationAnotation = MKPointAnnotation()
        
        destinationAnotation.title = "Ahemdabad"
        destinationAnotation.subtitle = "Ahmedabad, in western India, is the largest city in the state of Gujarat."
        if let location = destinationPlaceMark.location {
            destinationAnotation.coordinate = location.coordinate
        }
        
        self.mapView.showAnnotations([sourceAnotation, destinationAnotation], animated: true)
        
        
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = sourceMapItem
        directionRequest.destination = destinationItem
        directionRequest.transportType = .walking
        
        let direction = MKDirections(request: directionRequest)
        
        
        direction.calculate { (response, error) in
            guard let response = response else {
                if let error = error {
                    print("ERROR FOUND : \(error.localizedDescription)")
                }
                return
            }
            
            let route = response.routes[0]
            self.mapView.addOverlay(route.polyline, level: MKOverlayLevel.aboveRoads)
            
            let rect = route.polyline.boundingMapRect
            
            self.mapView.setRegion(MKCoordinateRegion(rect), animated: true)
            
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let rendere = MKPolylineRenderer(overlay: overlay)
        rendere.lineWidth = 5
        rendere.strokeColor = .systemBlue
        
        return rendere
    }
    
    func checkLocationAuthorization() {
        
      switch CLLocationManager.authorizationStatus() {
        
      case .authorizedWhenInUse:
            break
        
      case.denied:
            break
        
      case .notDetermined:
        locationManager.requestWhenInUseAuthorization()
        
      case .restricted:
            break
        
      case .authorizedAlways:
            break
      }

    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
    //        let userLocation:CLLocation = locations[0] as CLLocation
            guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
            locationManager.stopUpdatingLocation()
            print("locations = \(locValue.latitude) \(locValue.longitude)")
            
            locationManager.stopUpdatingLocation()
            //print(locations)
    }

    func fetchStadiumsOnMap(_ stadiums: [Stadium]) {
         for stadium in stadiums {
           let annotations = MKPointAnnotation()
           annotations.title = stadium.name
           annotations.coordinate = CLLocationCoordinate2D(latitude:
             stadium.lattitude, longitude: stadium.longtitude)
           mapView.addAnnotation(annotations)
         }
    }

}
```